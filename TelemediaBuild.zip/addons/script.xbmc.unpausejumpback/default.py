# -*- coding: utf-8 -*-

from resources.lib import unpause_jumpback

if __name__ == "__main__":
    unpause_jumpback.run()
